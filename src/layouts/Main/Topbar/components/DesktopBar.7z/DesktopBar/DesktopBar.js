import React, { useContext } from 'react'
import { Box,  IconButton } from '@mui/material'
import { FaUser } from 'react-icons/fa';
import AccountBalanceWalletIcon from '@mui/icons-material/AccountBalanceWallet';
import { NavLink } from 'react-router-dom';
import { Context } from 'hooks/WalletContext';
import Wallet from '../Wallet';
import { DrawerMobileContext } from 'hooks/DrawerMobileContext';
import { useTranslation } from 'react-i18next';
// import Notification from './components/Notification';
//import { autorizedAddress } from 'config/autorizedAddress';
import styled from '@emotion/styled';
import NotificationsNoneIcon from '@mui/icons-material/NotificationsNone';
//import Language from './components/Language';
import LanguageIcon from '@mui/icons-material/Language';
import PropTypes from 'prop-types';

const CustomNavLink = styled(NavLink)`
    text-decoration: none;
    color: #fff;
    font-size: 15px;
    border: none;
    background: '#fff';
    padding: 0px 0.6rem;
`;


const DesktopBar = ({tabs}) => {
    const { t } = useTranslation("translate");
    const { data } = useContext(Context);
    const { openWallet, setOpenWallet } = useContext(DrawerMobileContext);
    const handleOpenWallet = () => {
        /* disable scroll */
        window.scrollTo(0, 0);
        document.body.style.overflow = 'hidden';
        setOpenWallet(!openWallet);
    }
    const openTab = (tab) => {
        window.open(tab, '_blank');
    }
    return (
        <React.Fragment>
        <Box sx={{ display: { xs: 'none', md: 'flex' }, gap:'1rem',height:'90px', alignItems:'center'}}>
            {tabs.map((tab, index) => (
                <Box key={index} display='flex' alignItems='center'>
                    {tab.public ?
                        <Box onClick={()=>openTab(tab.path)} sx={{fontSize:'25px',cursor:'pointer',color:'#000',fontFamily:'Futura,Trebuchet MS,Arial,sans-serif '}}>{tab.name}</Box>
                        :
                        <Box component={CustomNavLink} 
                            style={isActive => ({
                                color: isActive ? "#000" : "#000",
                                background: isActive ? "transparent" : "transparent"
                            })} 
                            to={tab.path} 
                            sx={{fontSize:'25px', textDecoration:'none', color:'#000',fontFamily:'Futura,Trebuchet MS,Arial,sans-serif '}}
                        >
                            {tab.name}
                        </Box>
                    }
                </Box>
            ))}
            {(data && data.userAccount)  &&
            <Box 
                component={CustomNavLink} 
                style={isActive => ({
                    color: isActive ? "#000" : "#000",
                    background: isActive ? "transparent" : "transparent",
                })} 
                to='/create' 
                sx={{fontSize:'25px', textDecoration:'none', color:'#000', fontFamily:'Futura,Trebuchet MS,Arial,sans-serif '}}
            >
                {t('topbar.create')}
            </Box>}

            {data && data.userAccount && 
            <IconButton
                size="large"
                edge="end"
                aria-label="account of current user"
                aria-haspopup="true"
                color="inherit"
                component={CustomNavLink}
                //style={active}
                to={`/notifications?address=${data.userAccount}`}
                sx={{display:'none'}}
            >
                <NotificationsNoneIcon
                    //htmlColor="#ed2891"
                    htmlColor="#000"
                    sx={{
                    fontSize: '30px',
                    //color: '#EBECF0',
                    }}
                />
            </IconButton>
            }
            {/* <Notification /> */}
            {data && data.userAccount &&
            <IconButton
                size="large"
                edge="end"
                aria-label="account of current user"
                aria-haspopup="true"
                color="inherit"
                component={CustomNavLink}
                //style={active}
                to={`/profile?address=${data.userAccount}`}
            >
                <FaUser 
                    //color='#ed2891' 
                    color="#000"
                    size={22}
                />
            </IconButton>}
            {/* <Language /> */}
            <Box component='label' htmlFor="goog-te-combo" id="google_translate_element" sx={{display:{xs:'none',sm:'none',md:'flex'}, alignItems:'center', justifyContent:'center', marginLeft:'1rem', marginRight:'20px'}}>
                <LanguageIcon sx={{marginRight:'-20px',color:'#000'}} />
            </Box>
            <IconButton
                size="large"
                edge="end"
                aria-label="account of current user"
                aria-haspopup="true"
                color="inherit"
                onClick={handleOpenWallet}
            >
                <AccountBalanceWalletIcon
                    //htmlColor="#ed2891"
                    htmlColor="#000"
                    sx={{
                        fontSize: '30px',
                        //color: '#EBECF0',
                    }} 
                />
            </IconButton>
        </Box>
        <Wallet />
        </React.Fragment>
    )
}

DesktopBar.propTypes = {
    tabs: PropTypes.array,
}

export default DesktopBar